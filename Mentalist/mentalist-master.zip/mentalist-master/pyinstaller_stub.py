import mentalist.controller
mentalist.controller.main()
