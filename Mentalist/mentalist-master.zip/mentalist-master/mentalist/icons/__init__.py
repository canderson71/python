import os
icon_dir = os.path.dirname(os.path.realpath(__file__))
